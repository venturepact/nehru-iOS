//
//  PKUSAddressZip.h
//  PaymentKit Example
//
//  Created by Alex MacCaw on 2/17/13.
//  Copyright (c) 2013 Stripe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PKAddressZip.h"

@interface PKUSAddressZip : PKAddressZip
@end
