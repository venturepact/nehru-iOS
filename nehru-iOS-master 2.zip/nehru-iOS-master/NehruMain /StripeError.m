//
//  StripeError.m
//  Stripe
//
//  Created by Saikat Chakrabarti on 11/4/12.
//
//

#import "StripeError.h"

NSString *const StripeDomain = @"com.stripe.lib";
NSString * const STPCardErrorCodeKey = @"com.stripe.lib:CardErrorCodeKey";
NSString * const STPErrorMessageKey = @"com.stripe.lib:ErrorMessageKey";
NSString * const STPErrorParameterKey = @"com.stripe.lib:ErrorParameterKey";
NSString * const STPInvalidNumber = @"com.stripe.lib:InvalidNumber";
NSString * const STPInvalidExpMonth = @"com.stripe.lib:InvalidExpiryMonth";
NSString * const STPInvalidExpYear = @"com.stripe.lib:InvalidExpiryYear";
NSString * const STPInvalidCVC = @"com.stripe.lib:InvalidCVC";
NSString * const STPIncorrectNumber = @"com.stripe.lib:IncorrectNumber";
NSString * const STPExpiredCard = @"com.stripe.lib:ExpiredCard";
NSString * const STPCardDeclined = @"com.stripe.lib:CardDeclined";
NSString * const STPProcessingError = @"com.stripe.lib:ProcessingError";
NSString * const STPIncorrectCVC = @"com.stripe.lib:IncorrectCVC";