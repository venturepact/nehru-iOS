//
//  RWChekcoutDisplayCell.m
//  RWPuppies
//
//  Created by Pietro Rea on 12/26/12.
//  Copyright (c) 2012 Pietro Rea. All rights reserved.
//

#import "RWCheckoutDisplayCell.h"

@implementation RWCheckoutDisplayCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
