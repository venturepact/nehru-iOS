//
//  DataCategory.m
//  nehru
//
//  Created by admin on 20/12/13.
//  Copyright (c) 2013 nehru. All rights reserved.
//

#import "DataCategory.h"

@implementation DataCategory
@synthesize CategoryId;
@synthesize CategoryName;
@end
