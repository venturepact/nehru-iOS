//
//  nMainCatCell.h
//  nehru
//
//  Created by ADMIN on 11/28/13.
//  Copyright (c) 2013 nehru. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface nMainCatCell : UITableViewCell

@property(weak,nonatomic)IBOutlet UILabel *nMainCatTitleText;
@property(weak,nonatomic)IBOutlet UIImageView *nMainCatImg;

@end
