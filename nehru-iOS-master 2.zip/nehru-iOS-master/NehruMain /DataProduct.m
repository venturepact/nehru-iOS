//
//  DataProduct.m
//  nehru
//
//  Created by admin on 07/12/13.
//  Copyright (c) 2013 nehru. All rights reserved.
//

#import "DataProduct.h"

@implementation DataProduct
@synthesize ProductId;
@synthesize imgproduct;
@synthesize ProductName;
@synthesize ProductImage;
@synthesize ProductModel;
@synthesize CategoryId;
@synthesize productquantity;
@synthesize productUnitprice;
@synthesize productSubTotal;
@synthesize productImages;
@synthesize ArrProductSizes;
@synthesize CartTotal;
@synthesize isfavorite;
@synthesize productColor;
@synthesize productSize;
@end
