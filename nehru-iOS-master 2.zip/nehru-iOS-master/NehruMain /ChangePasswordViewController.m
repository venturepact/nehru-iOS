//
//  ChangePasswordViewController.m
//  nehru
//
//  Created by Raj on 08/01/14.
//  Copyright (c) 2014 nehru. All rights reserved.
//

#import "ChangePasswordViewController.h"

@interface ChangePasswordViewController ()

@end

@implementation ChangePasswordViewController
@synthesize mTxtNewPassword,mTxtConfrmPassword,mTxtEmailID;

- (void)viewDidLoad
{
    [super viewDidLoad];
 
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}
-(IBAction)mClickedChandePassword:(id)sender {
    NSString *tEmailID = [NSString stringWithFormat:@"%@",mTxtEmailID];
    NSString *tNewPassword = [NSString stringWithFormat:@"%@",mTxtNewPassword];
    NSString *tCnfrmPassword = [NSString stringWithFormat:@"%@",mTxtConfrmPassword];
    
    PFQuery *validLoginQuery=[PFQuery queryWithClassName:@"NehruUser"];
    [validLoginQuery whereKey:@"emailId" equalTo:mTxtEmailID.text];
        [validLoginQuery findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        if (!error) {
            // The find succeeded.
            if(objects.count==0)
            {
                UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Incorrect Information" message:@"Username or Password incorrect" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:Nil, nil];
                [alertview show];
            }
            else if(objects.count==1){
                PFObject *AppUser=[objects objectAtIndex:0];
                NSLog(@"App User %@",AppUser);
                PFObject *usrSignUp=[PFObject objectWithClassName:@"NehruUser"];
                NSUserDefaults *userDefaults=[NSUserDefaults standardUserDefaults];
                [userDefaults setObject:AppUser[@"objectId"] forKey:@"UserId"];
                [userDefaults setObject:AppUser[@"firstName"] forKey:@"firstName"];
                [userDefaults setObject:AppUser[@"lastName"] forKey:@"lastName"];
                [userDefaults setObject:AppUser[@"emailId"] forKey:@"emailId"];
                [userDefaults synchronize];
                
                [usrSignUp setObject:mTxtNewPassword.text forKey:@"userPassword"];

                [usrSignUp setObject:mTxtConfrmPassword.text forKey:@"userPassword"];
//                if (mTxtNewPassword.text==mTxtConfrmPassword.text) {
                UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Success" message:@"Password Successfully Changed" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:Nil, nil];
                alertview.tag=100867;
                [alertview show];
                mTxtEmailID.text=@"";
                mTxtNewPassword.text=@"";
                mTxtConfrmPassword.text = @"";
                //}
//                else {
//                    UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Try Again" message:@"Password Did not Match" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:Nil, nil];
//                    alertview.tag=100867;
//                    [alertview show];
//
//                    
//                }
            }
            else{
                UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Incorrect Information" message:@"Username or Password incorrect" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:Nil, nil];
                [alertview show];
            }
        }
        else {
            // Log details of the failure
            NSLog(@"Error: %@ %@", error, [error userInfo]);
        }
    }];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag==100867) {
        
     if(buttonIndex ==0)
     {
         [self.navigationController popToRootViewControllerAnimated:YES];

     }

    }
}
    -(BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
