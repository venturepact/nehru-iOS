//
//  DataCategory.h
//  nehru
//
//  Created by admin on 20/12/13.
//  Copyright (c) 2013 nehru. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataCategory : NSObject
@property(nonatomic,strong)NSString *CategoryId;
@property(nonatomic,strong)NSString *CategoryName;
@end
